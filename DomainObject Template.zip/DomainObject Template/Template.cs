﻿using System;
using SpeakFriend.Utilities;

namespace SpeakFriend.TrueOrFalse
{
    public class Template : IMutableDomainObject
    {
        public int Id { get; set; }



        public DateTime Modified { get; set; }
        public DateTime Created { get; set; }

        public Template()
        {
            
        }
    }
}
