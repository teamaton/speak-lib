﻿namespace SpeakFriend.TrueOrFalse
{
    public interface ITemplateRepository
    {
        void Create(Template template);
        void Update(Template template);
        void Delete(Template template);

        TemplateList GetAll();
        Template GetById(int templateId);
    }
}