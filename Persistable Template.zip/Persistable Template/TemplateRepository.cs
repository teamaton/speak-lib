﻿using NHibernate;
using SpeakFriend.Utilities;

namespace SpeakFriend.TrueOrFalse
{
    public class TemplateRepository : RepositoryDb<Template, TemplateList>, ITemplateRepository
    {
        public TemplateRepository(ISession session) : base(session){}
    }
}
