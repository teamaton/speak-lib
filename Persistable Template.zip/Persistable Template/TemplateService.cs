using System;
using System.Collections.Generic;
using SpeakFriend.Utilities;

namespace SpeakFriend.TrueOrFalse
{
    public class TemplateService : IDataService<Template>
    {

        private ITemplateRepository _repository;

        public TemplateService(ITemplateRepository repository)
        {
            _repository = repository;
        }
        
        public TemplateList GetAll()
        {
            return _repository.GetAll();
        }

        List<Template> IDataService<Template>.GetAll()
        {
            return GetAll();
        }

        public void Create(Template template)
        {
            template.Created = template.Modified = DateTime.Now;
            _repository.Create(template);
        }

        public void Create(TemplateList templates)
        {
            foreach (var template in templates)
                Create(template);
        }

        public void Update(Template template)
        {
            template.Modified = DateTime.Now;

            _repository.Update(template);
        }

        public void Delete(Template template)
        {
            _repository.Delete(template);
        }

        //public void Delete(int templateId)
        //{
        //    _repository.Delete(templateId);
        //}

        public Template GetById(int templateId)
        {
            return _repository.GetById(templateId);
        }
    }
}

