        private void Template(ContainerBuilder builder)
        {
            builder
                .Register(c => new TemplateService(c.Resolve<ITemplateRepository>()))
                .As<TemplateService>()
                .ContainerScoped();

            builder
                .Register(c => new TemplateRepository(c.Resolve<SessionManager>().Session))
                .As<ITemplateRepository>()
                .ContainerScoped();
        }