﻿using System.Collections.Generic;
using SpeakFriend.Utilities;

namespace SpeakFriend.TrueOrFalse
{
    public class TemplateList : PersistableList<Template>
    {
        public TemplateList(){}

        public TemplateList(IEnumerable<Template> list) : base(list){}
    }
}
